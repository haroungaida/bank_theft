#ifndef SCROLLING_H
#define SCROLLING_H

#include "background.c"
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

void scrolling (SDL_Rect camera,background *bg,SDL_Surface *screen);

#endif
