#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
//#include "background.c"
#include "scrolling.c"

void pause()
{
    int continuer = 1;
    SDL_Event event;


    while (continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
        }
    }
}
int main()
{
	SDL_Rect camera;
	background bg;
	SDL_Surface *screen = NULL;

	SDL_Init(SDL_INIT_VIDEO);
	screen = SDL_SetVideoMode(800,600, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
	SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
	bg=initbackground();
	affbackground (bg,screen);
	scrolling(camera,&bg,screen);
	SDL_Flip(screen);
	pause();
        return (0);
}
