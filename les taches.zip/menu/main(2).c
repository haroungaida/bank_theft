#include <stdio.h>

#include <stdlib.h>

#include <SDL/SDL.h>

#include "SDL/SDL_mixer.h"

#include "SDL/SDL_image.h"

#include "SDL/SDL_ttf.h"



int main(int argc, char *argv[])



{



    SDL_Surface *screen = NULL, *image = NULL, *texte = NULL;



    SDL_Surface *start=NULL, *settings=NULL, *quit=NULL, *volume1=NULL



    , *volume2=NULL , *back=NULL;



    SDL_Rect PositionEcran,textepos,startpos,settingspos,quitpos,volume1pos,volume2pos,backpos;



    TTF_Font *police = NULL;



    SDL_Color couleurNoire = {0, 0, 0}, couleurBlanche ={255, 255, 255};



    Mix_Music *music;



    Mix_Chunk *clickmusic;







    Uint8 *wav_buffer;















    int a=1,x,y,i;



    int v = 64;



    PositionEcran.x = 0;



    PositionEcran.y = 0;



    startpos.x=50;



    startpos.y=50;



    settingspos.x=50;



    settingspos.y=100;



    quitpos.x=50;



    quitpos.y=200;



    textepos.x=120;



    textepos.y=50;



    volume1pos.x=50;



    volume1pos.y=100;



    volume2pos.x=50;



    volume2pos.y=150;

    texteback.x=120;



    texteback.y=50;












    start=IMG_Load("start1.png");



    settings=IMG_Load("settings1.png");



    quit=IMG_Load("quit1.png");



    image = IMG_Load("menu.png");



    volume1 = IMG_Load ("volume+.png");



    volume2 = IMG_Load ("volume-.png");



    back = IMG_Load ("back1.png");























    int continuer = 1;



    int continuer1;



    TTF_Init();



    if(TTF_Init() == -1)



    {



        printf("Erreur : %s\n", TTF_GetError());



        exit(EXIT_FAILURE);



    }







    police = TTF_OpenFont("TIMES.ttf", 65);







    SDL_Init (SDL_INIT_VIDEO);







    if ( SDL_Init (SDL_INIT_VIDEO) != 0)



    {



        printf("Erreur : %s\n",SDL_GetError());



        return 1;



    }







    screen = SDL_SetVideoMode (515, 300, 32, SDL_HWSURFACE | SDL_DOUBLEBUF );







    if (screen == NULL)



    {



        printf("Erreur : %s\n",SDL_GetError());



        return 1;



    }







    if (image == NULL)



    {



        printf("Erreur : %s\n",SDL_GetError());



        return 1;



    }



    SDL_WM_SetCaption( "ASHYO'S ADVENTURE", NULL );







        SDL_Event event;



















        if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)



	    {



	    printf("%s",Mix_GetError());



	    }







            SDL_AudioSpec wavSpec;



            Uint32 wavLength;



            Uint8 *wavBuffer;



	    music = Mix_LoadMUS("musicmenu.mp3");



	    Mix_PlayMusic(music,-1);



            Mix_VolumeMusic(v);



	    clickmusic = Mix_LoadWAV("son.wav");



	    Mix_PlayChannel(-1,clickmusic,0);











    while (continuer)



    {



        SDL_BlitSurface(image, NULL, screen, &PositionEcran);



        SDL_BlitSurface(start,NULL,screen,&startpos);



        SDL_BlitSurface(settings,NULL,screen,&settingspos);



        SDL_BlitSurface(quit,NULL,screen,&quitpos);



        SDL_BlitSurface(texte, NULL, screen,&textepos);



        while (SDL_PollEvent (& event))



        {



            switch (event.type)



            {



               case SDL_QUIT:



               continuer = 0;



               break;



                case SDL_MOUSEMOTION:



                     x= event.motion.x;



                     y= event.motion.y;











               if(x>=startpos.x && x<=startpos.x+startpos.w && y>=startpos.y && y<=startpos.y+startpos.h)



						{







							start=IMG_Load("start2.png");



						      Mix_PlayChannel(1,clickmusic,0);







}















						else



						{



							start=IMG_Load("start1.png");



















						}











					 if(x>=settingspos.x && x<=settingspos.x+settingspos.w && y>=settingspos.y && y<=settingspos.y+settingspos.h)



						{







							settings=IMG_Load("settings2.png");











							Mix_PlayChannel(1,clickmusic,0);















						}



						else



						{



							settings=IMG_Load("settings1.png");







						}







	                                      if(x>=quitpos.x && x<=quitpos.x+quitpos.w && y>=quitpos.y && y<=quitpos.y+quitpos.h)



						{







							quit=IMG_Load("quit2.png");











							 						          Mix_PlayChannel(1,clickmusic,0);











						}



						else



						{



							quit=IMG_Load("quit1.png");







						}







					break;











        case SDL_MOUSEBUTTONDOWN:



        x = event.button.x;



        y = event.button.y;



        			if ((event.button.button == SDL_BUTTON_LEFT)&&(x>=quitpos.x && x<=quitpos.x+quitpos.w && y>=quitpos.y && y<=quitpos.y+quitpos.h))



					return(0);



else if ((event.button.button == SDL_BUTTON_LEFT) && (x < settingspos.x + settingspos.w) && (y > settingspos.y) && (y < settingspos.y + settingspos.h))







{



int set = 1;



while (set)



{



SDL_BlitSurface(image, NULL, screen,&PositionEcran);



SDL_BlitSurface(volume1,NULL,screen,&volume1pos);



SDL_BlitSurface(volume2, NULL, screen,&volume2pos);



SDL_BlitSurface(back,NULL,screen,&backpos);







SDL_Flip(screen);



while (SDL_PollEvent (&event))



{



     switch (event.type)



     {



        case SDL_MOUSEMOTION:



                     x= event.motion.x;



                     y= event.motion.y;







                       if(x>=volume1pos.x && x<=volume1pos.x+volume1pos.w && y>=volume1pos.y && y<=volume1pos.y+volume1pos.h)



						{







							volume1=IMG_Load("volume+2.png");



						       	Mix_PlayChannel(1,clickmusic,0);















						}



else



						{



							volume1=IMG_Load("volume+.png");







						}







                               if(x>=volume2pos.x && x<=volume2pos.x+volume2pos.w && y>=volume2pos.y && y<=volume2pos.y+volume2pos.h)



						{







							volume2=IMG_Load("volume-2.png");











Mix_PlayChannel(1,clickmusic,0);



















						}



						else



						{



							volume2=IMG_Load("volume-.png");







						}







if(x>=backpos.x && x<=backpos.x+backpos.w && y>=backpos.y && y<=backpos.y+backpos.h)



						{







							back=IMG_Load("back2.png");















         Mix_PlayChannel(1,clickmusic,0);















						}



						else



						{



							back=IMG_Load("back1.png");







						}



   break;







        case SDL_MOUSEBUTTONDOWN:



        x = event.button.x;



        y = event.button.y;



        			if ((event.button.button ==          SDL_BUTTON_LEFT)&&(x>=backpos.x && x<=backpos.x+backpos.w && y>=backpos.y && y<=backpos.y+backpos.h))



        			set = 0;







        if((event.button.button ==          SDL_BUTTON_LEFT)&&(x>=volume1pos.x && x<=volume1pos.x+volume1pos.w && y>=volume1pos.y && y<=volume1pos.y+volume1pos.h))



	{



	    v=v+10;



	    Mix_VolumeMusic(v);



	}







	if((event.button.button ==          SDL_BUTTON_LEFT)&&(x>=volume2pos.x && x<=volume2pos.x+volume2pos.w && y>=volume2pos.y && y<=volume2pos.y+volume2pos.h))



	{



	    v=v-10;



	    Mix_VolumeMusic(v);



	}











        break;



        case SDL_QUIT:



        return 0;



        break;



        case SDL_KEYDOWN:







      switch(event.key.keysym.sym){



      case  SDLK_f:



      screen = SDL_SetVideoMode (515, 300, 32,SDL_HWSURFACE |  SDL_DOUBLEBUF | SDL_FULLSCREEN);



      break;



      case SDLK_n:



      screen = SDL_SetVideoMode (515, 300, 32,SDL_HWSURFACE |  SDL_DOUBLEBUF );



      break;







      }



     }



}



}



}







	case SDL_KEYDOWN:







      switch(event.key.keysym.sym)







            {







            case SDLK_UP:



                if (i==1)



                    i=3;







                else











                    i--;



                break;







            case SDLK_DOWN:







                if(i==3)



                    i=1;







                else















                    i++;



                break;











            }











 if (i==1)



{



start=IMG_Load("start2.png");



settings=IMG_Load("settings1.png");



quit=IMG_Load("quit1.png");



}



if (i==2)



{



start=IMG_Load("start1.png");



settings=IMG_Load("settings2.png");



quit=IMG_Load("quit1.png");



}



if  (i==3)



{



start=IMG_Load("start1.png");



settings=IMG_Load("settings1.png");



quit=IMG_Load("quit2.png");



}











 }



 }







        SDL_Flip(screen);







	 }



	 }









